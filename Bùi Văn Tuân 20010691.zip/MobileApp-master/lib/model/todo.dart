class ToDo {
  String? id;
  String? todoText;
  bool isDone;
  String? Date;
  ToDo(
      {required this.id,
      required this.todoText,
      this.isDone = false,
      required this.Date});

  static List<ToDo> todoList() {
    return [
      ToDo(
          id: '01',
          todoText: 'Morning Excercise',
          isDone: true,
          Date: '17/03/2023'),
      ToDo(
          id: '02',
          todoText: 'Buy Groceries',
          isDone: true,
          Date: '17/03/2023'),
      ToDo(id: '03', todoText: 'Check Emails', Date: '17/03/2023'),
      ToDo(id: '04', todoText: 'Team Meeting', Date: '17/03/2023'),
      ToDo(
          id: '05',
          todoText: 'Work on mobile apps for 2 hour',
          Date: '17/03/2023'),
      ToDo(id: '06', todoText: 'Dinner with Jenny', Date: '17/03/2023'),
    ];
  }
}
