package com.example.managemant_task_person

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
